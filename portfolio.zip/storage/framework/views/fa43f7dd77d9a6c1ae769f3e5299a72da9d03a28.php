<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8" />
    <title>Aadil Safi: Skilled Laravel and React Developer | Expertise in Full-Stack Web Development</title>
    <meta name="description" content="Aadil Safi is a highly skilled Laravel, Vue and React developer with expertise in full-stack web development. With years of experience, Aadil is proficient in building robust and scalable web applications using Laravel and React. Hire Aadil Safi for your next project and unlock the potential of modern web development.">
    <meta name="keywords" property="og:title" content="Aadil Safi, Laravel developer, Vue Developer, React developer, full-stack web development, web applications, web development services, hire web developer">
    <meta property="og:description" content="Aadil Safi is a highly skilled Laravel and React developer with expertise in full-stack web development. With years of experience, Aadil is proficient in building robust and scalable web applications using Laravel and React. Hire Aadil Safi for your next project and unlock the potential of modern web development.">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>" type="image/x-icon">
    <!-- animate css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">
    <!-- bootstrap -->
    
    <link rel="stylesheet" href="https://cdn.usebootstrap.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- plugin -->
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.7.2/css/all.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <!-- responsive css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-5W6SLEYM7M"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-5W6SLEYM7M');
</script>
</head>

<body>
    <!-- preloader area start -->
    <div class="preloader" id="preloader">
        <div class="loader loader-1">
            <div class="loader-outter"></div>
            <div class="loader-inner"></div>
        </div>
    </div>
    <!-- preloader area end -->
    <!-- Menu toggle Icon Start -->
    <div class="toggle-icon">
        <div id="nav-icon3">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    <!-- Menu toggle Icon End -->
    <!-- Main Website wrapper start -->
    <div id="main">
        <!--Main-Menu Area Start-->
        <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--Main-Menu Area Start-->

        <!--Hero Area Start-->
        <section class="home section-bg active" id="home">
            <div class="h-100vh d-flex align-items-center">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="main-profile-image">
                                <img loading="lazy" src="<?php echo e(asset('assets/images/main-img.jpg')); ?>" alt="Profile Image">
                            </div>
                        </div>
                        <div class="col-lg-6  align-self-center">
                            <div class="hero-box text-left">
                                <span class="greeting">HELLO</span>
                                <h1 class="name h2">
                                    I'm <span>Aadil Safi</span> <span class="d-none"> Laravel, VueJs and React JS Developer</span>
                                </h1>

                                <h3 class="d-none">
                                    Laravel, VueJs and React JS Developer I can Build Complex Websites within no time.
                                </h3>

                                <h4 class="header_title"> I Do <span id="typed"></span></h4>
                                <p class="short-info">
                                    I'm a software engineer with 4+ years of experience possessing the skill set which
                                    enables me to play a part in the organization's goals. I'm good at Laravel, Vue js,,
                                    React js Javascript, Restful API, and Jquery. I'm passionate about my work and I
                                    love what I do. I'm highly organized and results-oriented, constantly checking in
                                    with the goal. In my downtime, I enjoy upgrading my skill set and reading about
                                    techs, innovations, and new methodologies.
                                </p>
                                <a id="g-p-f-h" class="pagelink mybtn mybtn-bg" href="#portfolio"><span><i
                                            class="fas fa-briefcase"></i>Portfolio</span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Hero Area End-->

        <!-- About Area Start -->
        <section id="about" class="about-area section-padding section-bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-heading">
                            <h2 class="s-h-title">
                                About <span>Me</span>
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="about-box">
                            <div class="row">
                                <div class="col-lg-6 d-flex align-self-center">
                                    <div class="about-content">
                                        <ul class="info-list">
                                            <li>
                                                <span class="title">First Name : </span>
                                                <span class="value">Aadil</span>
                                            </li>
                                            <li>
                                                <span class="title">Last Name : </span>
                                                <span class="value">Safi</span>
                                            </li>
                                            <li>
                                                <span class="title">Age : </span>
                                                <span class="value">25</span>
                                            </li>
                                            <li>
                                                <span class="title">Birthdate : </span>
                                                <span class="value">21 april 1998</span>
                                            </li>
                                            <li>
                                                <span class="title">Residence : </span>
                                                <span class="value">PAKISTAN</span>
                                            </li>
                                            <li>
                                                <span class="title">Langages : </span>
                                                <span class="value">English</span>
                                            </li>
                                            <li>
                                                <span class="title">Phone : </span>
                                                <span class="value">+923335021242</span>
                                            </li>
                                            <li>
                                                <span class="title">Email : </span>
                                                <span class="value">hello@aadilsafi.me</span>
                                            </li>
                                            <li>
                                                <span class="title">Freelance : </span><span
                                                    class="value">Available</span>
                                            </li>
                                            <li>
                                                <span class="title">Experience : </span><span class="value">4
                                                    years</span>
                                            </li>
                                            <li>
                                                <span class="title">Skype : </span><span class="value">aadilsafi</span>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                                <div class="col-lg-6 d-flex align-self-center">
                                    <div class="about-content">
                                        <div class="my-acivment-list">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="single-acivment one">
                                                        <div class="top-area">
                                                            <div class="icon">
                                                                <i class="far fa-heart"></i>
                                                            </div>
                                                            <div class="number">
                                                                <span class="n-counter">200</span><span
                                                                    class="plus">+</span>
                                                            </div>
                                                        </div>
                                                        <div class="content">

                                                            <h6 class="title">
                                                                Happy Clients
                                                            </h6>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="single-acivment two">
                                                        <div class="top-area">
                                                            <div class="icon">
                                                                <i class="fas fa-briefcase"></i>
                                                            </div>
                                                            <div class="number">
                                                                <span class="n-counter">203</span><span
                                                                    class="plus">+</span>
                                                            </div>
                                                        </div>
                                                        <div class="content">

                                                            <h6 class="title">
                                                                Project Done
                                                            </h6>
                                                        </div>
                                                    </div>
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row w-i-d">
                    <div class="col-lg-12">
                        <div class="section-heading">
                            <h2 class="s-h-title">
                                What I <span>Do</span>
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="row service-area-wrapper">
                    <div class="col-lg-4 col-md-6">
                        <div class="single-service service-modal ">
                            <img loading="lazy" src="<?php echo e(asset('assets/images/s1.png')); ?>" alt="SEO Optimization">
                            <h6 class="title">SEO</h6>
                            <p>As an SEO specialist, I help clients boost their online presence, increase website
                                visibility, drive targeted traffic, and achieve higher rankings in search engines.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-service service-modal ">
                            <img loading="lazy" src="<?php echo e(asset('assets/images/s5.png')); ?>" alt="Web Development">
                            <h6 class="title">Web Development</h6>
                            <p>As a web development professional, I create dynamic and responsive websites, leveraging
                                the latest technologies to deliver user-friendly interfaces and seamless online
                                experiences for clients and their customers.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-service service-modal ">
                            <img loading="lazy" src="<?php echo e(asset('assets/images/s6.png')); ?>" alt="Web Design">
                            <h6 class="title">Web Design</h6>
                            <p>As a web design aficionado, I blend creativity with functionality to craft visually
                                stunning and intuitive websites that captivate users and effectively communicate my
                                clients' brand message.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-service service-modal ">
                            <img loading="lazy" src="<?php echo e(asset('assets/images/s2.png')); ?>" alt="Graphic Design">
                            <h6 class="title">Graphic Design</h6>
                            <p>With expertise in graphic design, I craft compelling visuals, deliver impactful designs,
                                and create unforgettable branding solutions that leave a lasting impression for my
                                clients.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-service service-modal ">
                            <img loading="lazy" src="<?php echo e(asset('assets/images/s3.png')); ?>" alt="API Integeration">
                            <h6 class="title">API Integeration</h6>
                            <p>As an API integration expert, I seamlessly connect systems, enhance functionality, and
                                streamline processes for clients, ensuring efficient data exchange and optimized
                                workflows.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-service service-modal ">
                            <img loading="lazy" src="<?php echo e(asset('assets/images/s4.png')); ?>" alt="Amazon AWS">
                            <h6 class="title">Amazon AWS</h6>
                            <p>As an Amazon AWS specialist, I harness the power of cloud computing, ensuring scalable
                                infrastructure, secure data storage, and reliable services for clients' digital
                                operations.</p>
                        </div>
                    </div>
                </div>
                <div class="row w-i-d">
                    <div class="col-lg-12">
                        <div class="section-heading">
                            <h2 class="s-h-title">
                                <span>My</span> Testimonial
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="single-review">
                            <div class="reviewr">
                                <div class="img">
                                    <img loading="lazy" src="<?php echo e(asset('assets/images/rev1.jpg')); ?>" alt="Shane H.">
                                </div>
                                <div class="content">
                                    <h4 class="name">
                                        Shane H.
                                    </h4>
                                </div>
                            </div>
                            <div class="stars">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="content">
                                <p>
                                    Aadil S. is very easy to work with and meets all of my expectations!
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-review">
                            <div class="reviewr">
                                <div class="img">
                                    <img loading="lazy" src="<?php echo e(asset('assets/images/rev2.jpg')); ?>" alt="Alen Doe">
                                </div>
                                <div class="content">
                                    <h4 class="name">
                                        Alen Doe
                                    </h4>
                                    <p>
                                        CEO of Apple
                                    </p>
                                </div>
                            </div>
                            <div class="stars">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="content">
                                <p>
                                    Believed attentive assisted picture sharpness to I to she waved the are and slide
                                    understand the that
                                    set task. The you due back.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-review">
                            <div class="reviewr">
                                <div class="img">
                                    <img loading="lazy" src="<?php echo e(asset('assets/images/rev3.jpg')); ?>" alt="Zachary">
                                </div>
                                <div class="content">
                                    <h4 class="name">
                                        Zachary
                                    </h4>
                                    <p>
                                        CTO at IdealDevs
                                    </p>
                                </div>
                            </div>
                            <div class="stars">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="content">
                                <p>
                                    Believed attentive assisted picture sharpness to I to she waved the are and slide
                                    understand the that
                                    set task. The you due back.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-review">
                            <div class="reviewr">
                                <div class="img">
                                    <img loading="lazy" src="<?php echo e(asset('assets/images/rev1.jpg')); ?>" alt="Nathaniel">
                                </div>
                                <div class="content">
                                    <h4 class="name">
                                        Nathaniel
                                    </h4>
                                    <p>
                                        COO at IdealDevs
                                    </p>
                                </div>
                            </div>
                            <div class="stars">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="content">
                                <p>
                                    Believed attentive assisted picture sharpness to I to she waved the are and slide
                                    understand the that
                                    set task. The you due back.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-review">
                            <div class="reviewr">
                                <div class="img">
                                    <img loading="lazy" src="<?php echo e(asset('assets/images/rev2.jpg')); ?>" alt="Harrison">
                                </div>
                                <div class="content">
                                    <h4 class="name">
                                        Harrison
                                    </h4>
                                    <p>
                                        DH at IdealDevs
                                    </p>
                                </div>
                            </div>
                            <div class="stars">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="content">
                                <p>
                                    Believed attentive assisted picture sharpness to I to she waved the are and slide
                                    understand the that
                                    set task. The you due back.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-review">
                            <div class="reviewr">
                                <div class="img">
                                    <img loading="lazy" src="<?php echo e(asset('assets/images/rev3.jpg')); ?>" alt="Jameson">
                                </div>
                                <div class="content">
                                    <h4 class="name">
                                        Jameson
                                    </h4>
                                    <p>
                                        CEO at IdealDevs
                                    </p>
                                </div>
                            </div>
                            <div class="stars">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="content">
                                <p>
                                    Believed attentive assisted picture sharpness to I to she waved the are and slide
                                    understand the that
                                    set task. The you due back.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>
        <!-- About Area End -->

        <!-- Resume Area Start -->
        <section id="resume" class="about-area section-padding section-bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-heading">
                            <h2 class="s-h-title">
                                My <span>Resume</span>
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="about-box">
                            <div class="row">
                                <div class="col-lg-6 d-flex align-self-center">
                                    <div class="about-content">
                                        <a href="<?php echo e(asset('assets/resume.pdf')); ?>" class="mybtn mybtn-bg" download>
                                            <span><i class="fas fa-download"></i>Download My CV</span> </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="eduandex" class="eduandex">
                <div class="container">

                    <div class="row skill-area" id="statisticsSection">
                        <div class="col-lg-6 skill-area-line">
                            <div class="skill-box">
                                <h4 class="title">
                                    Coding Skills
                                </h4>
                                <div class="skill-list">
                                    <div class="single-skill">
                                        <div class="label">
                                            <h2 class="h6">CSS</h2>
                                            <span>95%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                role="progressbar" aria-valuenow="80" aria-valuemin="0"
                                                aria-valuemax="100" style="width: 95%"></div>
                                        </div>
                                    </div>
                                    <div class="single-skill">
                                        <div class="label">
                                            <h2 class="h6">HTML</h2>
                                            <span>98%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                role="progressbar" aria-valuenow="95" aria-valuemin="0"
                                                aria-valuemax="100" style="width: 98%"></div>
                                        </div>
                                    </div>
                                    <div class="single-skill">
                                        <div class="label">
                                            <h2 class="h6">PHP</h2>
                                            <span>92%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                role="progressbar" aria-valuenow="75" aria-valuemin="0"
                                                aria-valuemax="100" style="width: 92%"></div>
                                        </div>
                                    </div>
                                    <div class="single-skill">
                                        <div class="label">
                                            <h2 class="h6">JS</h2>
                                            <span>95%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                role="progressbar" aria-valuenow="90" aria-valuemin="0"
                                                aria-valuemax="100" style="width: 95%"></div>
                                        </div>
                                    </div>
                                    <div class="single-skill">
                                        <div class="label">
                                            <h2 class="h6">React</h2>
                                            <span>85%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                role="progressbar" aria-valuenow="90" aria-valuemin="0"
                                                aria-valuemax="100" style="width: 85%"></div>
                                        </div>
                                    </div>
                                    <div class="single-skill">
                                        <div class="label">
                                            <h2 class="h6">Laravel</h2>
                                            <span>95%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                role="progressbar" aria-valuenow="90" aria-valuemin="0"
                                                aria-valuemax="100" style="width: 95%"></div>
                                        </div>
                                    </div>
                                    <div class="single-skill">
                                        <div class="label">
                                            <h2 class="h6">Vue</h2>
                                            <span>85%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                role="progressbar" aria-valuenow="90" aria-valuemin="0"
                                                aria-valuemax="100" style="width: 85%"></div>
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 skill-area-line">
                            <div class="skill-box">
                                <h4 class="title">
                                    Language Skills
                                </h4>
                                <div class="skill-list">
                                    <div class="single-skill">
                                        <div class="label">
                                            <span>Hindi</span>
                                            <span>99%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                role="progressbar" aria-valuenow="92" aria-valuemin="0"
                                                aria-valuemax="100" style="width: 99%"></div>
                                        </div>
                                    </div>
                                    <div class="single-skill">
                                        <div class="label">
                                            <span>Urdu</span>
                                            <span>99%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                role="progressbar" aria-valuenow="92" aria-valuemin="0"
                                                aria-valuemax="100" style="width: 99%"></div>
                                        </div>
                                    </div>
                                    <div class="single-skill">
                                        <div class="label">
                                            <span>Arabic</span>
                                            <span>60%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                role="progressbar" aria-valuenow="88" aria-valuemin="0"
                                                aria-valuemax="100" style="width: 60%"></div>
                                        </div>
                                    </div>
                                    <div class="single-skill">
                                        <div class="label">
                                            <span>Spanish</span>
                                            <span>40%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                role="progressbar" aria-valuenow="80" aria-valuemin="0"
                                                aria-valuemax="100" style="width: 40%"></div>
                                        </div>
                                    </div>
                                    <div class="single-skill">
                                        <div class="label">
                                            <span>English</span>
                                            <span>99%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                role="progressbar" aria-valuenow="99" aria-valuemin="0"
                                                aria-valuemax="100" style="width: 99%"></div>
                                        </div>
                                    </div>
                                    <div class="single-skill">
                                        <div class="label">
                                            <span>German</span>
                                            <span>40%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated"
                                                role="progressbar" aria-valuenow="99" aria-valuemin="0"
                                                aria-valuemax="100" style="width: 40%"></div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 skill-area-circle">
                            <div class="skill-box">
                                <h4 class="title">
                                    Professional Skills
                                </h4>
                                <div class="skill-list">
                                    <div class="single-skill">
                                        <div class="progress-circle position" data-percent="90" data-duration="1000"
                                            data-color="#e9ecef, 304CFD"></div>
                                        <div class="label mt-1 d-block text-center">
                                            <span>Web Design</span>
                                        </div>
                                    </div>
                                    <div class="single-skill">
                                        <div class="progress-circle position" data-percent="96" data-duration="1000"
                                            data-color="#e9ecef, 304CFD"></div>
                                        <div class="label mt-1 d-block text-center">
                                            <span>Web Devlopment</span>
                                        </div>
                                    </div>
                                    <div class="single-skill">
                                        <div class="progress-circle position" data-percent="80" data-duration="1000"
                                            data-color="#e9ecef, 304CFD"></div>
                                        <div class="label mt-1 d-block text-center">
                                            <span>Graphic Design</span>
                                        </div>
                                    </div>
                                    <div class="single-skill">
                                        <div class="progress-circle position" data-percent="80" data-duration="1000"
                                            data-color="#e9ecef, 304CFD"></div>
                                        <div class="label mt-1 d-block text-center">
                                            <span>SEO</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 skill-area-circle">
                            <div class="skill-box">
                                <h4 class="title">
                                    Basic Knowledge
                                </h4>
                                <div class="skill-list">
                                    <ul class="single-list-ul">
                                        <li>
                                            <p>Search engine marketing</p>
                                        </li>
                                        <li>
                                            <p>iOS and android apps</p>
                                        </li>
                                        <li>
                                            <p>Spreadsheets (Excel, Google Spreadsheets, etc.)</p>
                                        </li>
                                        <li>
                                            <p>Software testing</p>
                                        </li>
                                        <li>
                                            <p>Presentation software (PowerPoint, Keynote)</p>
                                        </li>
                                        <li>
                                            <p>Office suites (Microsoft Office, G Suite)</p>
                                        </li>
                                        <li>
                                            <p>SQA</p>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="edu-box">
                                <h2 class="title">Education</h2>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="education-list">
                                            <div class="single-education">
                                                <h4 class="collage-name">
                                                    National University of Modern Languages
                                                </h4>
                                                <p class="degree">Software Engeering<span class="year">2017 -
                                                        2021</span>
                                                </p>
                                                <div class="description">
                                                    <p>
                                                        The National University of Modern Languages is a public research
                                                        university with
                                                        campuses in Pakistan and China.
                                                    </p>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="edu-box">
                                <h2 class="title">Experience</h2>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="education-list">
                                            <div class="single-education">
                                                <h4 class="collage-name">
                                                    Red cubez
                                                </h4>
                                                <p class="degree">Software Engineer
                                                </p>
                                                <div class="description">
                                                    <p>
                                                        RedCubez provides web development and SaaS solutions. It create
                                                        stunning websites and offer flexible SaaS products to boost your
                                                        online presence and streamline your business processes.
                                                    </p>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Resume Area End -->

        <!-- Portfolio Area Start -->
        <section id="portfolio" class="project-gallery section-padding  section-bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-heading">
                            <h2 class="s-h-title">
                                My <span>Portfolio</span>
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="project-gallery-filter d-flex justify-content-center">
                            <ul class="project-gallery-menu d-inline-block">
                                <li class="filter active" data-filter="all">All</li>
                                <li class="filter" data-filter=".cat-1">Services</li>
                                <li class="filter" data-filter=".cat-2">E-commerce</li>
                                <li class="filter" data-filter=".cat-3">General</li>
                            </ul>
                        </div>
                        <div class="row ">
                            <div class="mix col-md-6 col-lg-4  cat-1 ">
                                <a href="https://www.bnbpk.com/" target="_blank">
                                    <div class="gallery-item-content pp">
                                        <div class="item-thumbnail">
                                            <img loading="lazy" src="<?php echo e(asset('assets/images/bnb1.webp')); ?>" class="portfolio" alt="BNBPK Web">
                                            <div class="content-overlay">
                                                <div class="content">
                                                    <h4 class="project-title">
                                                        BNBPk
                                                    </h4>
                                                    <span class="project-category">Services</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="mix col-md-6 col-lg-4 gallery-item  cat-2">
                                <a href="#" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/commerce.webp')); ?>" class="portfolio" alt="Velocity">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Velocity
                                                </h4>
                                                <span class="project-category">E-commerce store</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item cat-2 ">
                                <a href="" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/commerce-2.webp')); ?>" class="portfolio" alt="Recommend4u">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Recommend4U
                                                </h4>
                                                <span class="project-category">E-commerce store</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item cat-3">
                                <a href="#" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/lms1.webp')); ?>" class="portfolio" alt="LMS">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    LMS
                                                </h4>
                                                <span class="project-category">General</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item cat-3 ">
                                <a href="#" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/mayor.webp')); ?>" class="portfolio" alt="Businesss Analysis Dashboard">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Businesss Analysis Dashboard
                                                </h4>
                                                <span class="project-category">General</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item cat-1 ">
                                <a href="https://www.dentinect.co/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/medical.webp')); ?>" class="portfolio" alt="Dentinect">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Dentinect
                                                </h4>
                                                <span class="project-category">Services</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item cat-1">
                                <a href="https://checkpeople.com/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/public.webp')); ?>" class="portfolio" alt="CheckPeople">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    CheckPeople
                                                </h4>
                                                <span class="project-category">Services</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item cat-2">
                                <a href="https://www.zebra.com.pk/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/zebra.webp')); ?>" class="portfolio" alt="Zebra E-commerce Store">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Zebra
                                                </h4>
                                                <span class="project-category">E-commerce Store</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item  cat-1">
                                <a href="https://www.gulfwheels.com/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/services1.webp')); ?>" class="portfolio" alt="Gulf Wheels Classifieds for cars">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Gulf Wheels
                                                </h4>
                                                <span class="project-category">Services</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item  cat-1">
                                <a href="http://www.drrahavard.com/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/services2.webp')); ?>" class="portfolio" alt="Valley Regenerative Pain Clinic">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Valley Regenerative Pain Clinic
                                                </h4>
                                                <span class="project-category">Services</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item  cat-1">
                                <a href="https://www.trueloadtime.com/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/services3.webp')); ?>" class="portfolio" alt="True Load Time">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    True Load Time
                                                </h4>
                                                <span class="project-category">Services</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item  cat-1">
                                <a href="https://www.grappos.com/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/services5.webp')); ?>" class="portfolio" alt="Grappos">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Grappos
                                                </h4>
                                                <span class="project-category">Services</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item  cat-1">
                                <a href="https://secur.space/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/services6.webp')); ?>" class="portfolio" alt="Secur Space">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Secur Space
                                                </h4>
                                                <span class="project-category">Services</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item  cat-1">
                                <a href="https://anglia-copyandprint.co.uk/" target="_blank"
                                    class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/services8.webp')); ?>" class="portfolio" alt="Anglia">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Anglia
                                                </h4>
                                                <span class="project-category">Services</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item  cat-1">
                                <a href="https://evernote.com/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/services10.webp')); ?>" class="portfolio" alt="Evernote">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Evernote
                                                </h4>
                                                <span class="project-category">Services</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item  cat-1">
                                <a href="https://www.globoclik.com/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/services11.webp')); ?>" class="portfolio" alt="Globo Click">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Globo Click
                                                </h4>
                                                <span class="project-category">Services</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item  cat-1">
                                <a href="http://mvsaatchi.com/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/services12.webp')); ?>" class="portfolio" alt="MV Satchi">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    MV Satchi
                                                </h4>
                                                <span class="project-category">Services</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item  cat-1">
                                <a href="https://www.intellistarsaba.com/" target="_blank"
                                    class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/services13.webp')); ?>" class="portfolio" alt="Intellistars">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Intellistars
                                                </h4>
                                                <span class="project-category">Services</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item cat-2">
                                <a href="https://easystore.shop/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/commerce3.webp')); ?>" class="portfolio" alt="Easy Store">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Easy Store
                                                </h4>
                                                <span class="project-category">E-Commerce Store</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item cat-2">
                                <a href="https://opkix.com.au/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/commerce4.webp')); ?>" class="portfolio" alt="Opikix">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Opikix
                                                </h4>
                                                <span class="project-category">E-Commerce Store</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item cat-2">
                                <a href="https://styleseekerz.com/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/commerce5.webp')); ?>" class="portfolio" alt="Style Seekers">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Style Seekers
                                                </h4>
                                                <span class="project-category">E-Commerce Store</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item cat-2">
                                <a href="https://noisetteetchocolat.ca/" target="_blank"
                                    class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/commerce7.webp')); ?>" class="portfolio" alt="Noisette & Chocolat">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Noisette & Chocolat
                                                </h4>
                                                <span class="project-category">E-Commerce Store</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item cat-2">
                                <a href="https://tecgloves.com/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/commerce10.webp')); ?>" class="portfolio" alt="Tec gloves E-Commerce Store">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Tec gloves
                                                </h4>
                                                <span class="project-category">E-Commerce Store</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item cat-3">
                                <a href="https://www.kindly.ai/" target="_blank" class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/general1.webp')); ?>" class="portfolio" alt="Kindly">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    Kindly
                                                </h4>
                                                <span class="project-category">Gemeral</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="mix col-md-6 col-lg-4 gallery-item cat-3">
                                <a href="https://www.happy-monk-media.de/" target="_blank"
                                    class="gallery-item-content pp">
                                    <div class="item-thumbnail">
                                        <img loading="lazy" src="<?php echo e(asset('assets/images/general2.webp')); ?>" class="portfolio" alt="UGC">
                                        <div class="content-overlay">
                                            <div class="content">
                                                <h4 class="project-title">
                                                    UGC
                                                </h4>
                                                <span class="project-category">General</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>

        <!-- Portfolio Area End -->

        <!-- Blog List  Area Start -->

        <!-- Blog List  Area End -->

        <!-- Contact Us Area Start -->
        <section class="contact contact-info-area section-padding  section-bg" id="contact">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-heading">
                            <h2 class="s-h-title">
                                Contact <span>Me</span>
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">

                    <div class="col-lg-4 col-md-6">
                        <!-- Single Info -->
                        <a href="tel:+923335021242">
                            <div class="single-info">
                                <div class="info-icon">
                                    <i class="fa fa-phone"></i>
                                </div>
                                <div class="info-content">
                                    <h5>Phone Number:</h5>
                                    <p>+923335021242</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <a href="mailto:hello@aadilsafi.me">
                            <!-- Single Info -->
                            <div class="single-info">

                                <div class="info-icon">
                                    <i class="fa fa-envelope"></i>
                                </div>
                                <div class="info-contentr">
                                    <h5>Email Address:</h5>
                                    <p>hello@aadilsafi.me</p>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="row cAndm justify-content-center">
                    <div class="col-md-8">
                        <div class="home-page-form">
                            <div class="contact-form">
                                <form id="contact-form" method="post" action="https://idealdevs.net/porichoy/sendmail">
                                    <input type="hidden" name="_token" value="U58FZo5N9knWeZ9Bp0aIjs2rZ5NOuJ4ej3SCbpB4">
                                    <div class="controls">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <i class="fa fa-user-o"></i>
                                                    <input id="form_name" type="text" name="name" class="form-control"
                                                        placeholder="Name" required="required"
                                                        data-error="Name is required.">
                                                    <div class="help-block with-errors"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <i class="fa fa-envelope-o"></i>
                                                    <input id="form_email" type="email" name="email"
                                                        class="form-control" placeholder="Email*" required="required"
                                                        data-error="Valid email is required.">
                                                    <div class="help-block with-errors"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <i class="fa fa-question-circle-o"></i>
                                                    <input id="form_subject" type="text" name="subject"
                                                        class="form-control" placeholder="Subject*" required="required"
                                                        data-error="Subject is required.">
                                                    <div class="help-block with-errors"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <i class="fa fa-comment-o"></i>
                                                    <textarea id="form_message" name="message" class="form-control"
                                                        placeholder="Message*" rows="7" required="required"
                                                        data-error="Please,leave us a message."></textarea>
                                                    <div class="help-block with-errors"></div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <button type="submit" class="mybtn mybtn-bg"><span>Send
                                                        Message</span></button>
                                            </div>
                                        </div>
                                    </div>
                                </form> <!-- End Contact From -->

                                <div class="social-link text-center">
                                    <ul class="wrap">
                                        <li class="wow fadeInUp">
                                            <a href="https://www.facebook.com/aadilsafi" target="_blank"><i
                                                    class="fab fa-facebook-f"></i></a>
                                        </li>

                                        <li class="wow fadeInUp">
                                            <a href="https://www.linkedin.com/in/aadilsafi/" target="_blank"><i
                                                    class="fab fa-linkedin-in"></i></a>
                                        </li>
                                        <li class="wow fadeInUp">
                                            <a href="https://www.instagram.com/aadilsafi/" target="_blank"><i
                                                    class="fab fa-instagram"></i></a>
                                        </li>
                                        <li class="wow fadeInUp">
                                            <a href="https://www.freelancer.com/u/aadilsafii" target="_blank"><i
                                                    class="fa fa-laptop"></i></a>
                                        </li>
                                        <li class="wow fadeInUp">
                                            <a href="https://www.fiverr.com/aadilsafi" target="_blank"><i
                                                    class="fa fa-f">F</i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>

                <!--/.row-->
            </div>
        </section>
        <!-- Contact Us Area End -->
    </div>
    <!-- Main Website wrapper End -->

    <!-- Blog Modal Start-->

    <!-- Blog Modal End-->

    <!-- Main jquery and all jquery plugin hear -->
    <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('assets/js/mixitup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/typed.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
</body>

</html>
<?php /**PATH /home/aadilsafi/sandbox/aadil-portfolio/resources/views/layouts/master.blade.php ENDPATH**/ ?>