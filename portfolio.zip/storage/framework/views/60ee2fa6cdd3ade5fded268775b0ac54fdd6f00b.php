<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__("Skills")); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    
                    <form action="<?php echo e(route('about_me.update', $skill->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-4">
                            <label for="image" class="block text-gray-600">Image</label>
                            <input type="file" name="image" id="image" class="border border-gray-300 rounded-md p-2 w-full">
                        </div>
                        <div class="mb-4">
                            <label for="title" class="block text-gray-600">Title</label>
                            <input type="text" name="title" id="title" value="<?php echo e(old('title', $skill->title)); ?>" class="border border-gray-300 rounded-md p-2 w-full" required>
                        </div>
                        <div class="mb-4">
                            <label for="description" class="block text-gray-600">Description</label>
                            <textarea name="description" id="description" class="border border-gray-300 rounded-md p-2 w-full" required><?php echo e(old('description', $skill->description)); ?></textarea>
                        </div>
                        <div class="mb-4">
                            <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600">Update Skill</button>
                        </div>
                    </form>
                
  
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\portfolio\resources\views/about_me/edit.blade.php ENDPATH**/ ?>