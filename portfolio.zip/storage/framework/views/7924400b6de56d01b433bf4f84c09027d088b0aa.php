
		<!--Main-Menu Area Start-->
		<div class="mainmenu-area">
			<nav class="my-navbar">
				<ul class="navbar-links">
					<li class="mynav-item active">
						<a class="mynav-link active" href="#home">Home</a>
					</li>
					<li class="mynav-item">
						<a class="mynav-link" href="#about">About</a>
					</li>
					<li class="mynav-item">
						<a class="mynav-link" href="#resume">Resume</a>
					</li>
					<li class="mynav-item portfolio">
						<a class="mynav-link portfolio" href="#portfolio">Portfolio</a>
					</li>

					<li class="mynav-item">
						<a class="mynav-link" href="#contact" id="contact-top">Contact</a>
					</li>
				</ul>
			</nav>
		</div>
		<!--Main-Menu Area Start-->
<?php /**PATH C:\laragon\www\portfolio\resources\views/layouts/topbar.blade.php ENDPATH**/ ?>